# Wordpress for Docker image appsvcorg/wordpress-alpine-php

This branch will be cloned when starting [appsvcorg/wordpress-alpine-php](https://hub.docker.com/r/appsvcorg/wordpress-alpine-php/) by default.

- Current version: 5.2 [(offical zip)](https://wordpress.org/wordpress-5.2.zip)
- Include Redis plugin
- Include Really Simple SSL plugin

[More Details](https://hub.docker.com/r/appsvcorg/wordpress-alpine-php/) of appsvcorg/wordpress-alpine-php.